from setuptools import setup

setup(
	name="testpackage",
	version="0.1",
	description="attempt at python package",
	author="Leeor Vardi",
	author_email="leeor.v@quali.com",
	url="http://quali.com",
	packages=["testpackage"],
	install_requires=[]
)