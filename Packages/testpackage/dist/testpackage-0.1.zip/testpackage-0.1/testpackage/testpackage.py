class testpackage:
	def __init__(self):
		self.string = "Hello World"

	def printmessage(self):
		print self.string